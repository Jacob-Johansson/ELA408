classdef DStarTag < uint32
   enumeration
      NEW (0), OPEN (1), CLOSED (2)
   end
end